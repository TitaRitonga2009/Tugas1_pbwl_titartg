<?php
$pelangganManager = new PelangganManager($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $golongan = $_POST['golongan'];
        $nomorPelanggan = $_POST['nomor_pelanggan'];
        $namaPelanggan = $_POST['nama_pelanggan'];
        $alamatPelanggan = $_POST['alamat_pelanggan'];
        $noHpPelanggan = $_POST['no_hp_pelanggan'];
        $ktpPelanggan = $_POST['ktp_pelanggan'];
        $nomorSeri = $_POST['nomor_seri'];
        $noMeteranPelanggan = $_POST['no_meteran_pelanggan'];
        $pelangganAktif = isset($_POST['pelanggan_aktif']) ? 1 : 0;

        if ($_POST['action'] == 'tambah_pelanggan') {
            $pelangganManager->tambahPelanggan($golongan, $nomorPelanggan, $namaPelanggan, $alamatPelanggan, $noHpPelanggan, $ktpPelanggan, $nomorSeri, $noMeteranPelanggan, $pelangganAktif);
        } elseif ($_POST['action'] == 'edit_pelanggan') {
            $idPelanggan = $_POST['edit_id_pelanggan'];
            $pelangganManager->editPelanggan($idPelanggan, $golongan, $nomorPelanggan, $namaPelanggan, $alamatPelanggan, $noHpPelanggan, $ktpPelanggan, $nomorSeri, $noMeteranPelanggan, $pelangganAktif);
        }
    }
}

if (isset($_GET['hapus_pelanggan'])) {
    $idPelangganHapus = $_GET['hapus_pelanggan'];
    $pelangganManager->hapusPelanggan($idPelangganHapus);
}

$pelanggans = $pelangganManager->getDataPelanggan();

// Fungsi untuk mendapatkan daftar golongan
function getGolongans($conn) {
    $result = $conn->query("SELECT * FROM golongan");
    $golongans = $result->fetch_all(MYSQLI_ASSOC);

    return $golongans;
}
$golongans = getGolongans($conn);

// Menjalankan query untuk mendapatkan data pelanggan
$result = $conn->query("SELECT * FROM pelanggan");
$pelanggans = $result->fetch_all(MYSQLI_ASSOC);
?>