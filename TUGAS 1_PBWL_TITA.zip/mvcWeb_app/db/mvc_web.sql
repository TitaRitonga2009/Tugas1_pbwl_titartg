-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 30, 2023 at 03:50 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mvc_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `golongan`
--

CREATE TABLE `golongan` (
  `id_golongan` int NOT NULL,
  `kode_golongan` varchar(255) DEFAULT NULL,
  `nama_golongan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `golongan`
--

INSERT INTO `golongan` (`id_golongan`, `kode_golongan`, `nama_golongan`, `created_at`, `updated_at`) VALUES
(1, '2112', 'golongan 1', '2023-11-29 10:50:41', NULL),
(2, '211233', 'golongan 4', '2023-11-29 12:53:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int NOT NULL,
  `golongan` varchar(255) NOT NULL,
  `nomor_pelanggan` varchar(255) NOT NULL,
  `nama_pelanggan` varchar(255) DEFAULT NULL,
  `alamat_pelanggan` varchar(255) DEFAULT NULL,
  `no_hp_pelanggan` varchar(20) DEFAULT NULL,
  `ktp_pelanggan` varchar(20) DEFAULT NULL,
  `nomor_seri` varchar(50) DEFAULT NULL,
  `no_meteran_pelanggan` varchar(20) DEFAULT NULL,
  `pelanggan_aktif` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `golongan`, `nomor_pelanggan`, `nama_pelanggan`, `alamat_pelanggan`, `no_hp_pelanggan`, `ktp_pelanggan`, `nomor_seri`, `no_meteran_pelanggan`, `pelanggan_aktif`, `created_at`, `updated_at`) VALUES
(2, 'golongan1', '2112', 'nama 1', 'xax', '9082', '12212', '09080', '2112', 1, '2023-11-29 12:04:45', '2023-11-29 12:27:44'),
(3, 'golongan 4', '2112dsds', 'nama 2', 'zzz', '9082', '12212', '9080', '2112', 1, '2023-11-29 12:04:58', '2023-11-29 17:00:35'),
(4, 'golongan121', '2112dsds', 'nama 3', 'zzz', '9082', '12212', '9080', '2112', 0, '2023-11-29 12:15:59', '2023-11-29 12:58:28'),
(5, 'golongan 1', '2112666', 'nama 3dsccc', 'ccccccccvvvvvvv', '9082323232', '1221223232', '9080', '21122323232', 1, '2023-11-29 17:01:49', '2023-11-29 17:01:56');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int NOT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_nama` varchar(255) DEFAULT NULL,
  `user_alamat` text,
  `user_hp` varchar(255) DEFAULT NULL,
  `user_pos` varchar(255) DEFAULT NULL,
  `user_role` enum('admin','user') DEFAULT 'user',
  `user_aktif` tinyint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_email`, `user_password`, `user_nama`, `user_alamat`, `user_hp`, `user_pos`, `user_role`, `user_aktif`, `created_at`, `updated_at`) VALUES
(3, 'user@gmail.com', '123', 'admin', 'Sumatera Utara', '09282', '2121', 'user', 1, '2023-11-29 10:47:49', '2023-11-30 10:06:55'),
(4, 'user2@gmail.com', '123', 'user', 'Sumatera Utara', '09282', '2121', 'user', 1, '2023-11-29 11:44:36', '2023-11-30 00:03:21'),
(5, 'user@gmail.com', 'user', 'admin', 'Sumatera Utara', '09282', '2121', 'user', 1, '2023-11-29 17:07:30', NULL),
(6, 'user@gmail.com', '123', 'user', 'Sumatera Utara', '09282', '2121', 'admin', 1, '2023-11-30 03:07:37', '2023-11-30 10:22:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `golongan`
--
ALTER TABLE `golongan`
  ADD PRIMARY KEY (`id_golongan`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `golongan`
--
ALTER TABLE `golongan`
  MODIFY `id_golongan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
