<?php
include('../App/Config/Config.php');
include('../App/controller/ControllerUser.php');
include('../Model/ModelUser.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>

    <div class="container mt-5">
    <a href="golongan" class="btn btn-warning">Data Golongan</a>
    <a href="user" class="btn btn-info">Data Pengguna</a>
    <a href="pelanggan" class="btn btn-success">Data Pelanggan</a>
    <a href="logout" class="btn btn-danger">Keluar</a>
        <h2>Data User</h2>

        <!-- Tombol Tambah -->
        <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalUser">Tambah User</button>

        <!-- Tabel Data User -->
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Nama</th>
                    <th>Role</th>
                    <th>Aktif</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($users as $user) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $user['user_email']; ?></td>
                    <td><input class="form-label" type="password" value="<?= $user['user_password']; ?>"readonly></td>
                    <td><?= $user['user_nama']; ?></td>
                    <td><?= $user['user_role']; ?></td>
                    <td><?= $user['user_aktif'] ? 'Aktif' : 'Nonaktif'; ?></td>
                    <td>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal"
                            data-bs-target="#modalEditUser<?= $user['user_id']; ?>">Edit</button>
                        <a href="?hapus_user=<?= $user['user_id']; ?>" class="btn btn-danger btn-sm"
                            onclick="return confirm('Apakah Anda yakin ingin menghapus user ini?')">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Modal Tambah User -->
    <div class="modal fade" id="modalUser" tabindex="-1" aria-labelledby="modalUserLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalUserLabel">Tambah User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Form Tambah User -->
                    <form action="user.php" method="POST">
                        <input type="hidden" name="action" value="tambah_user">
                        <div class="mb-3 input-group">
                            <span class="input-group-text" id="basic-addon1">@</span>
                            <!-- <label for="user_email" class="form-label">Email</label> -->
                            <input type="email" class="form-control" id="user_email" name="user_email" required>
                        </div>
                        <div class="mb-3">
                            <label for="user_password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="user_password" name="user_password"
                                required>
                        </div>
                        <div class="mb-3">
                            <label for="user_nama" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="user_nama" name="user_nama" required>
                        </div>
                        <div class="mb-3">
                            <label for="user_alamat" class="form-label">Alamat</label>
                            <textarea class="form-control" id="user_alamat" name="user_alamat"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="user_hp" class="form-label">No. HP</label>
                            <input type="text" class="form-control" id="user_hp" name="user_hp">
                        </div>
                        <div class="mb-3">
                            <label for="user_pos" class="form-label">Pos</label>
                            <input type="text" class="form-control" id="user_pos" name="user_pos">
                        </div>
                        <div class="mb-3">
                            <label for="user_role" class="form-label">Role</label>
                            <select class="form-control" id="user_role" name="user_role">
                                <option value="admin">Admin</option>
                                <option value="user" selected>User</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="user_aktif" class="form-label">Aktif</label>
                            <select class="form-control" id="user_aktif" name="user_aktif">
                                <option value="1">Ya</option>
                                <option value="0">Tidak</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Edit User -->
    <?php foreach ($users as $user) : ?>
    <div class="modal fade" id="modalEditUser<?= $user['user_id']; ?>" tabindex="-1"
        aria-labelledby="modalEditUserLabel<?= $user['user_id']; ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditUserLabel<?= $user['user_id']; ?>">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Form Edit User -->
                    <form action="user.php" method="POST">
                        <input type="hidden" name="action" value="edit_user">
                        <input type="hidden" name="edit_user_id" value="<?= $user['user_id']; ?>">
                        <div class="mb-3">
                            <label for="edit_user_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit_user_email" name="edit_user_email"
                                value="<?= $user['user_email']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_user_password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="edit_user_password"
                                name="edit_user_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_user_nama" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="edit_user_nama" name="edit_user_nama"
                                value="<?= $user['user_nama']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_user_alamat" class="form-label">Alamat</label>
                            <textarea class="form-control" id="edit_user_alamat"
                                name="edit_user_alamat"><?= $user['user_alamat']; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="edit_user_hp" class="form-label">No. HP</label>
                            <input type="text" class="form-control" id="edit_user_hp" name="edit_user_hp"
                                value="<?= $user['user_hp']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="edit_user_pos" class="form-label">Pos</label>
                            <input type="text" class="form-control" id="edit_user_pos" name="edit_user_pos"
                                value="<?= $user['user_pos']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="edit_user_role" class="form-label">Role</label>
                            <select class="form-control" id="edit_user_role" name="edit_user_role">
                                <option value="admin" <?= $user['user_role'] === 'admin' ? 'selected' : ''; ?>>Admin
                                </option>
                                <option value="user" <?= $user['user_role'] === 'user' ? 'selected' : ''; ?>>User
                                </option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_user_aktif" class="form-label">Aktif</label>
                            <select class="form-control" id="edit_user_aktif" name="edit_user_aktif">
                                <option value="1" <?= $user['user_aktif'] ? 'selected' : ''; ?>>Ya</option>
                                <option value="0" <?= !$user['user_aktif'] ? 'selected' : ''; ?>>Tidak</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>

</html>
