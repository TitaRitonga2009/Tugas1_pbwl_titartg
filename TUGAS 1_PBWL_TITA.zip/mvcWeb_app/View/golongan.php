<?php
include('../App/Config/Config.php');
include('../App/controller/ControllerGolongan.php');
include('../Model/ModelGolongan.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Golongan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>

<div class="container mt-5">
    <a href="golongan" class="btn btn-warning">Data Golongan</a>
    <a href="user" class="btn btn-info">Data Pengguna</a>
    <a href="pelanggan" class="btn btn-success">Data Pelanggan</a>
    <a href="logout" class="btn btn-danger">Keluar</a>
    <h2>Data Golongan</h2>

    <!-- Tombol Tambah -->
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalGolongan">Tambah Golongan</button>

    <!-- Tabel Data Golongan -->
    <table class="table">
        <thead>
            <tr>
                <th>ID Golongan</th>
                <th>Kode Golongan</th>
                <th>Nama Golongan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($golongans as $golongan) : ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $golongan['kode_golongan']; ?></td>
                    <td><?= $golongan['nama_golongan']; ?></td>
                    <td>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalEditGolongan<?= $golongan['id_golongan']; ?>">Edit</button>
                        <a href="?hapus_golongan=<?= $golongan['id_golongan']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus golongan ini?')">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal Tambah Golongan -->
<div class="modal fade" id="modalGolongan" tabindex="-1" aria-labelledby="modalGolonganLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalGolonganLabel">Tambah Golongan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Form Tambah Golongan -->
                <form action="golongan.php" method="POST">
                    <input type="hidden" name="action" value="tambah_golongan">
                    <div class="mb-3">
                        <label for="kode_golongan" class="form-label">Kode Golongan</label>
                        <input type="text" class="form-control" id="kode_golongan" name="kode_golongan" required>
                    </div>
                    <div class="mb-3">
                        <label for="nama_golongan" class="form-label">Nama Golongan</label>
                        <input type="text" class="form-control" id="nama_golongan" name="nama_golongan" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Tambah</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit Golongan -->
<?php foreach ($golongans as $golongan) : ?>
    <div class="modal fade" id="modalEditGolongan<?= $golongan['id_golongan']; ?>" tabindex="-1" aria-labelledby="modalEditGolonganLabel<?= $golongan['id_golongan']; ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditGolonganLabel<?= $golongan['id_golongan']; ?>">Edit Golongan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Form Edit Golongan -->
                    <form action="golongan.php" method="POST">
                        <input type="hidden" name="action" value="edit_golongan">
                        <input type="hidden" name="edit_id_golongan" value="<?= $golongan['id_golongan']; ?>">
                        <div class="mb-3">
                            <label for="edit_kode_golongan" class="form-label">Kode Golongan</label>
                            <input type="text" class="form-control" id="edit_kode_golongan" name="edit_kode_golongan" value="<?= $golongan['kode_golongan']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_nama_golongan" class="form-label">Nama Golongan</label>
                            <input type="text" class="form-control" id="edit_nama_golongan" name="edit_nama_golongan" value="<?= $golongan['nama_golongan']; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
