<?php
class User
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function bacaDataUser()
    {
        $sql = "SELECT * FROM user";
        $result = $this->conn->query($sql);

        if (!$result) {
            die("Error: " . $this->conn->error);
        }

        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function tambahUser($data)
    {
        $email = $this->conn->real_escape_string($data['user_email']);
        $password = $this->conn->real_escape_string($data['user_password']);
        $nama = $this->conn->real_escape_string($data['user_nama']);
        $alamat = $this->conn->real_escape_string($data['user_alamat']);
        $hp = $this->conn->real_escape_string($data['user_hp']);
        $pos = $this->conn->real_escape_string($data['user_pos']);
        $role = $this->conn->real_escape_string($data['user_role']);
        $aktif = $this->conn->real_escape_string($data['user_aktif']);

        $sql = "INSERT INTO user (user_email, user_password, user_nama, user_alamat, user_hp, user_pos, user_role, user_aktif, created_at) 
                VALUES ('$email', '$password', '$nama', '$alamat', '$hp', '$pos', '$role', '$aktif', NOW())";

        if ($this->conn->query($sql) === FALSE) {
            die("Error: " . $this->conn->error);
        }
    }

    public function editUser($data)
    {
        $id = $this->conn->real_escape_string($data['edit_user_id']);
        $email = $this->conn->real_escape_string($data['edit_user_email']);
        $password = $this->conn->real_escape_string($data['edit_user_password']);
        $nama = $this->conn->real_escape_string($data['edit_user_nama']);
        $alamat = $this->conn->real_escape_string($data['edit_user_alamat']);
        $hp = $this->conn->real_escape_string($data['edit_user_hp']);
        $pos = $this->conn->real_escape_string($data['edit_user_pos']);
        $role = $this->conn->real_escape_string($data['edit_user_role']);
        $aktif = $this->conn->real_escape_string($data['edit_user_aktif']);

        $sql = "UPDATE user SET user_email='$email', user_password='$password', user_nama='$nama', user_alamat='$alamat', 
                user_hp='$hp', user_pos='$pos', user_role='$role', user_aktif='$aktif', updated_at=NOW() WHERE user_id=$id";

        if ($this->conn->query($sql) === FALSE) {
            die("Error: " . $this->conn->error);
        }
    }

    public function hapusUser($id)
    {
        $id = $this->conn->real_escape_string($id);

        $sql = "DELETE FROM user WHERE user_id=$id";

        if ($this->conn->query($sql) === FALSE) {
            die("Error: " . $this->conn->error);
        }
    }
}