<?php
class Golongan
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function bacaDataGolongan()
    {
        $sql = "SELECT * FROM golongan";
        $result = $this->conn->query($sql);

        if (!$result) {
            die("Error: " . $this->conn->error);
        }

        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getNextGolonganId($golongans)
    {
        $lastGolongan = end($golongans);
        return $lastGolongan ? $lastGolongan['id_golongan'] + 1 : 1;
    }

    public function tambahGolongan($kode_golongan, $nama_golongan)
    {
        $kode_golongan = $this->conn->real_escape_string($kode_golongan);
        $nama_golongan = $this->conn->real_escape_string($nama_golongan);

        $sql = "INSERT INTO golongan (kode_golongan, nama_golongan, created_at) VALUES ('$kode_golongan', '$nama_golongan', NOW())";

        if ($this->conn->query($sql) === FALSE) {
            die("Error: " . $this->conn->error);
        }
    }

    public function editGolongan($id_golongan, $kode_golongan, $nama_golongan)
    {
        $kode_golongan = $this->conn->real_escape_string($kode_golongan);
        $nama_golongan = $this->conn->real_escape_string($nama_golongan);

        $sql = "UPDATE golongan SET kode_golongan='$kode_golongan', nama_golongan='$nama_golongan' WHERE id_golongan=$id_golongan";

        if ($this->conn->query($sql) === FALSE) {
            die("Error: " . $this->conn->error);
        }
    }

    public function hapusGolongan($id_golongan)
    {
        $id_golongan = $this->conn->real_escape_string($id_golongan);

        $sql = "DELETE FROM golongan WHERE id_golongan=$id_golongan";

        if ($this->conn->query($sql) === FALSE) {
            die("Error: " . $this->conn->error);
        }
    }
}

?>